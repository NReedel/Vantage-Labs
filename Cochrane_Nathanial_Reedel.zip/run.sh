#!/bin/bash

# ========================================
# Cochrane Library Crawler - Run Script
# Starts backend (Spring Boot) and frontend (React)
# Compatible with both Windows (via WSL) and native Linux
# ========================================

# Resolve absolute paths for reliability
PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
BACKEND_DIR="$PROJECT_ROOT/backend"
FRONTEND_DIR="$PROJECT_ROOT/frontend"
BACKEND_LOG_DIR="$BACKEND_DIR/logs"
LOG_FILE="$BACKEND_LOG_DIR/backend.log"

# Ensure backend logs directory exists
mkdir -p "$BACKEND_LOG_DIR"

# ----------------------------------------
# Cross-platform prep (for WSL after Windows run)
# ----------------------------------------
echo ""
echo "🔧 Preparing WSL environment..."
# Kill any old Node or Java processes left by Windows/WSL
pkill -f "java" 2>/dev/null || true
pkill -f "node" 2>/dev/null || true

# Normalize CRLF → LF line endings (skip errors if dos2unix not installed)
echo "🧹 Normalizing text files..."
find "$BACKEND_DIR/src/main/resources/static" -type f -name "*.txt" -exec dos2unix {} \; 2>/dev/null || true

# Fix permissions that Windows may mark read-only
chmod -R u+rw "$BACKEND_DIR/src/main/resources/static" 2>/dev/null || true

# ----------------------------------------
# Helper functions
# ----------------------------------------
run_command() {
  echo "🔹 Running: $1"
  eval "$1"
}

free_port() {
  local PORT=$1
  echo "🔹 Checking for existing process on port $PORT..."
  if command -v npx >/dev/null 2>&1; then
    npx kill-port $PORT >/dev/null 2>&1 || true
  else
    if lsof -i :$PORT >/dev/null 2>&1; then
      echo "⚠️ Port $PORT is in use. Stopping the process..."
      lsof -ti :$PORT | xargs kill -15
      sleep 2
    else
      echo "✅ Port $PORT is free."
    fi
  fi
}

# Free backend (8080) and frontend (3000) ports
free_port 8080
free_port 3000

# ----------------------------------------
# Start Backend
# ----------------------------------------
echo "🚀 Starting Backend..."
cd "$BACKEND_DIR" || { echo "❌ Backend directory not found! Exiting..."; exit 1; }

run_command "mvn clean install" || { echo "❌ Maven build failed! Exiting..."; exit 1; }

echo "🔹 Creating new backend log file..."
> "$LOG_FILE"

echo "🔹 Launching Spring Boot backend..."
nohup mvn spring-boot:run > "$LOG_FILE" 2>&1 &
BACKEND_PID=$!

echo "⏳ Waiting for backend to start..."
until curl -s http://localhost:8080/api/reviews >/dev/null; do
  sleep 2
  echo "⏳ Still waiting for backend..."
done
echo "✅ Backend is up and running."

# ----------------------------------------
# Start Frontend
# ----------------------------------------
echo "🚀 Starting Frontend..."
cd "$FRONTEND_DIR" || { echo "❌ Frontend directory not found! Exiting..."; exit 1; }

if command -v nvm >/dev/null 2>&1; then
  echo "🔹 Setting correct Node.js version..."
  run_command "nvm use"
fi

if [ ! -d "node_modules" ]; then
  echo "🔹 node_modules not found. Running npm install..."
  run_command "npm install"
else
  echo "✅ node_modules found. Skipping npm install."
fi

echo "🔹 Starting React frontend..."
run_command "npm start"

# ----------------------------------------
# Graceful cleanup on exit
# ----------------------------------------
cleanup() {
  echo ""
  echo "🛑 Stopping backend..."
  kill -15 "$BACKEND_PID" 2>/dev/null || echo "⚠️ Backend was not running."

  echo "🧩 Releasing resources..."
  pkill -f "java" 2>/dev/null || true
  pkill -f "node" 2>/dev/null || true
  echo "✅ All services stopped. Exiting cleanly."
  exit 0
}

trap cleanup SIGINT SIGTERM

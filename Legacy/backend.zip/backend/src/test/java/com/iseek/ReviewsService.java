package com.iseek;

public class ReviewsService {

}

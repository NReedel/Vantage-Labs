package com.iseek;

public class ReviewsController {

}

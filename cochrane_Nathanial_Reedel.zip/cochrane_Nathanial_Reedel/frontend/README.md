# Frontend - Cochrane Library Crawler

## Overview
The **frontend** is a React-based web interface for browsing Cochrane Reviews. It provides a search bar, dynamic filtering, and an infinite scroll feature to display reviews.

## Tech Stack
- **React 18+**
- **JavaScript (ES6+)**
- **Fetch API** (for API calls)
- **CSS Modules** (for styling)

## Setup Instructions
### 1️⃣ Prerequisites
Ensure you have:
- **Node.js 16+** installed (`node -v`)
- **npm** installed (`npm -v`)

### 2️⃣ Installing Dependencies
Navigate to the frontend directory:
```bash
cd frontend
npm install
```
This will install all required packages listed in `package.json`.

### 3️⃣ Running the Frontend
Start the React development server:
```bash
npm start
```
- The frontend will be available at **http://localhost:3000**.
- Ensure the backend is running before starting the frontend.

### 4️⃣ Stopping the Frontend
Press **Ctrl + C** to stop the React server.
Or manually stop the process:
```bash
kill $(lsof -ti :3000)
```

## Project Structure
```
frontend/
│── public/           # Static HTML files
│── src/
│   ├── api/         # API calls (fetchReviews.js)
│   ├── components/  # UI components (ReviewItem, SearchBox)
│   ├── pages/       # Page views (Home.js)
│── package.json     # Dependencies
```

## Additional Resources
- [React Documentation](https://react.dev/)
- [MDN Fetch API](https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API)


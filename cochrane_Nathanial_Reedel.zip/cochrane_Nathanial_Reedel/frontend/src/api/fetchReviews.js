/* 
 * API Handler: Fetch Reviews 
 * This function retrieves Cochrane reviews from the backend API.
 */

export async function fetchReviews(query = "") {
    try {
        const encodedQuery = encodeURIComponent(query);
        const response = await fetch(`http://localhost:8080/api/reviews?query=${encodedQuery}`);
        const data = await response.json();

        if (data.length > 0) {
            console.log(`Found ${data.length} reviews for query: "${query}"`);
            return data;
        } else {
            console.log(`No reviews found for query: "${query}"`);
            return []; // ✅ Return an empty array, let ReviewList.js handle it!
        }
    } catch (error) {
        console.error("Error fetching reviews:", error);
        return [];
    }
}
# Backend - Cochrane Library Crawler

## Overview
The **backend** is a Spring Boot application responsible for scraping, processing, and serving Cochrane Reviews through a REST API. It scrapes topics from the Cochrane Library, stores them, and exposes structured endpoints for the frontend.

## Tech Stack
- **Java 17+**
- **Spring Boot 3+**
- **Maven** (Build Tool)
- **JSoup** (Web Scraping Library)
- **Jackson** (JSON Processing)

## Project Structure
```
backend/
│── pom.xml                         # Maven Build Configuration
│── logs/                           # Backend logs
│   ├── application.log              # Application log file
│── src/
│   ├── main/java/iseek/            # Java Source Code
│   │   ├── Application.java        # Main Spring Boot Application
│   │   ├── CochraneScraper.java    # Scrapes Cochrane Reviews
│   │   ├── DataStorage.java        # (For testing) Stores scraped data
│   │   ├── ReviewController.java   # REST API Endpoints
│   │   ├── ReviewMetadata.java     # Review Data Model
│   │   ├── ReviewService.java      # Service layer for handling logic
│   │   ├── TopicSuggestionService.java # Fetches topics for search suggestions
│   ├── resources/
│   │   ├── application.properties  # Backend Configuration
│   │   ├── cochrane_reviews.json   # (Testing) Stored reviews data
```

## Setup Instructions
### 1️⃣ Prerequisites
Ensure you have:
- **Java 17+** installed (`java -version`)
- **Maven** installed (`mvn -version`)

### 2️⃣ Building the Project
Navigate to the backend directory:
```bash
cd backend
mvn clean install
```
This will compile the Java code, resolve dependencies, and prepare the application.

### 3️⃣ Running the Backend
Start the Spring Boot server:
```bash
mvn spring-boot:run
```
- The backend will be available at **http://localhost:8080**.
- API endpoint for reviews: **`GET /api/reviews`**

### 4️⃣ Logs & Debugging
Logs are stored in the `logs/` directory.
To tail logs:
```bash
tail -f logs/application.log
```

### 5️⃣ Stopping the Backend
Press **Ctrl + C** to stop the server.
Or manually stop the process:
```bash
kill $(lsof -ti :8080)
```

## API Endpoints
| Method | Endpoint        | Description |
|--------|----------------|-------------|
| GET    | /api/reviews   | Fetch all Cochrane Reviews |
| GET    | /api/suggestions | Get available topics |

## Additional Resources
- [Spring Boot Documentation](https://spring.io/projects/spring-boot)
- [JSoup Documentation](https://jsoup.org/)
- [Maven Documentation](https://maven.apache.org/)


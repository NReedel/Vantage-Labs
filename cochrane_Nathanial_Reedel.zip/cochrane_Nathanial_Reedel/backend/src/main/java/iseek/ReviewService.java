package iseek;

/**
 * Service class responsible for managing and processing Cochrane review data.
 * This class fetches and stores review metadata. 
 * Has pagnation features which need further development to implement.
 */

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Service;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class ReviewService {

	private static final String TOPICS_URL = "https://www.cochranelibrary.com/cdsr/reviews/topics";

	public List<ReviewMetadata> fetchReviewsByTopic(String query) {
		System.out.println("Starting review extraction for topic: " + query);
		String topicUrl = getTopicUrl(query);

		if (topicUrl == null) {
			return new ArrayList<>();
		}

		List<ReviewMetadata> reviews = scrapeReviews(topicUrl, query);
		return reviews;
	}

	private String getTopicUrl(String query) {
		try {
			Document topicsPage = Jsoup.connect(TOPICS_URL).get();
			Elements topicLinks = topicsPage.select("li.browse-by-list-item a");

			for (Element link : topicLinks) {
				String topicName = link.text().trim();
				if (topicName.equalsIgnoreCase(query)) {
					String extractedUrl = link.absUrl("href");
					// Extracted topic URL: extractedUrl
					return extractedUrl;
				}
			}
		} catch (IOException e) {
			System.err.println("Error fetching topic URL: " + e.getMessage());
		}
		return null;
	}

	private List<ReviewMetadata> scrapeReviews(String topicUrl, String query) {
		List<ReviewMetadata> reviews = new ArrayList<>();
		int currentPage = 1;
		int totalReviews = -1;

		try {
			String currentUrl = topicUrl;

			while (currentUrl != null) {
				// Scraping page: currentUrl
				Document pageDoc = Jsoup.connect(currentUrl).get();

				// Detect total number of reviews on the first page
				if (totalReviews == -1) {
					Element totalReviewsElement = pageDoc.selectFirst(".search-results-header__count");
					if (totalReviewsElement != null) {
						String totalReviewsText = totalReviewsElement.text().replaceAll("[^0-9]", "");
						totalReviews = Integer.parseInt(totalReviewsText);
						// Total reviews detected: totalReviews
					} else {
						totalReviews = Integer.MAX_VALUE;
					}
				}

				// Extract reviews
				Elements reviewElements = pageDoc.select(".search-results-item");
				int reviewsBefore = reviews.size();

				for (Element reviewElement : reviewElements) {
					String title = reviewElement.select(".result-title a").text();
					String url = reviewElement.select(".result-title a").attr("href");
					String authors = reviewElement.select(".search-result-authors").text();
					String date = reviewElement.select(".search-result-date").text();

					if (!url.startsWith("http")) {
						url = "https://www.cochranelibrary.com" + url;
					}

					reviews.add(new ReviewMetadata(url, query, title, authors, date));

					// Stop if we reach the total expected reviews
					if (reviews.size() >= totalReviews) {
						// Reached total expected reviews: totalReviews
						return reviews;
					}
				}

				// Check if no new reviews were added (possible infinite loop)
				if (reviews.size() == reviewsBefore) {
					System.out.println("No new reviews found on this page. Stopping to prevent infinite loop.");
					break;
				}

				// Detect pagination method
				Element nextPageElement = pageDoc.select("a.pagination-next").first();
				if (nextPageElement != null) {
					currentUrl = nextPageElement.absUrl("href");
					System.out.println("Next page URL: " + currentUrl);
				} else {
					currentUrl = topicUrl + "&cur=" + (++currentPage);
				}
			}

		} catch (IOException e) {
			System.err.println("Error fetching reviews: " + e.getMessage());
		}

		return reviews;
	}
}

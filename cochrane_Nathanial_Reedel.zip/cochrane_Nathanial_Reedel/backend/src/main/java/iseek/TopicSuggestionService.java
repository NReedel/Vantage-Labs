package iseek;

/**
 * This service generates and provides topic suggestions for search functionality.
 * It loads topics dynamically to assist in user input auto-suggestions.
 */

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Service;
import jakarta.annotation.PostConstruct;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class TopicSuggestionService {

	private static final String COCHRANE_URL = "https://www.cochranelibrary.com/cdsr/reviews/topics";
	private static final String FILE_PATH = "src/main/resources/static/suggestions.txt";

	@PostConstruct
	public void generateSuggestions() {
		System.out.println("Starting topic suggestions generation...");
		List<String> topics = scrapeTopics();

		if (topics.isEmpty()) {
			System.out.println("No topics found. Logging error to suggestions.txt");
		} else {
			// "Extracted " + topics.size() + " topics."
			saveTopicsToFile(topics);
		}
	}

	private List<String> scrapeTopics() {
		List<String> topics = new ArrayList<>();
		try {
			Document doc = Jsoup.connect(COCHRANE_URL).get();

			// Correct selector: Extracting all <a> inside <li class="browse-by-list-item">
			Elements topicElements = doc.select("li.browse-by-list-item a");

			for (Element topic : topicElements) {
				String topicText = topic.text().trim();
				if (!topicText.isEmpty()) {
					topics.add(topicText);
				}
			}
		} catch (IOException e) {
			String errorMessage = "Error fetching topics from Cochrane Library: " + e.getMessage();
			System.err.println(errorMessage);
		}
		return topics;
	}

	private void saveTopicsToFile(List<String> topics) {
		File file = new File(FILE_PATH);
		file.getParentFile().mkdirs(); // Ensure directory exists

		try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, false))) { // Overwrite file each time
			for (String topic : topics) {
				writer.write(topic);
				writer.newLine();
			} // Successfully writes topics to suggestions.txt
		} catch (IOException e) {
			String errorMessage = "Error writing to suggestions.txt: " + e.getMessage();
			System.err.println(errorMessage);
		}
	}

}
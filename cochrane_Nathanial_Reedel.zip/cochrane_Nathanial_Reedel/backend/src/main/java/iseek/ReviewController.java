package iseek;

/**
 * REST Controller that handles API requests for Cochrane reviews.
 * Provides endpoints to fetch review data dynamically.
 */

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:3000")
public class ReviewController {

	private static final String SUGGESTIONS_FILE = "src/main/resources/static/suggestions.txt";

	@Autowired
	private ReviewService reviewService;

	@GetMapping("/reviews")
	public List<ReviewMetadata> getReviews(@RequestParam(required = false) String query) {
		List<ReviewMetadata> reviews = reviewService.fetchReviewsByTopic(query);
		return reviews;
	}

	@GetMapping("/suggestions")
	public List<String> getSuggestions() {
		try {
			// Fetching topic suggestions
			return Files.lines(Paths.get(SUGGESTIONS_FILE))
					.map(String::trim)
					.filter(line -> !line.isEmpty())
					.collect(Collectors.toList());
		} catch (IOException e) {
			// Error reading suggestions file: {}", e.getMessage()
			return List.of(); // Return an empty list in case of error
		}
	}
}
